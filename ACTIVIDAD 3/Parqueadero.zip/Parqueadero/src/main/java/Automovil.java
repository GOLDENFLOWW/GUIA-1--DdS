import java.io.*;
import java.util.*;
import java.time.LocalDateTime;

/**
 * 
 */
public class Automovil extends Vehiculo {
     public String tipoCombustible;

    /**
     * Default constructor
     */
    public Automovil(String placa, String marca, String modelo, String tipoCombustible, LocalDateTime horaEntrada) {
        super(placa, marca, modelo, horaEntrada);
        this.tipoCombustible = tipoCombustible;
    }

    // Getters y Setters
    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoCombustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;

    }

}