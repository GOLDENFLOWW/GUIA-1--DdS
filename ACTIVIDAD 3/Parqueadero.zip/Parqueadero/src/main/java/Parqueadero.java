import java.time.*;
import java.io.*;
import java.util.*;

class Parqueadero {
    private List<Vehiculo> Vehiculos;
    
    public List<Vehiculo> consultarEstado() {
        return Vehiculos; // Devuelve la lista de vehículos actual
    }

    public Parqueadero() {
        this.Vehiculos = new ArrayList<>();
    }

    public void registrarEntrada(Vehiculo vehiculo) {
        Vehiculos.add(vehiculo);
        System.out.println("Vehículo registrado con éxito.");
    }

    public double registrarSalida(String placa) {
    for (Vehiculo vehiculo : Vehiculos) {
        if (vehiculo.getPlaca().equals(placa)) {
            Vehiculos.remove(vehiculo); 
            Duration duration = Duration.between(vehiculo.getHoraEntrada(), LocalDateTime.now());
            long horas = duration.toHours(); // Obtener las horas de la duración
            if (horas == 0) horas = 1; 

            if (vehiculo instanceof Automovil) {
                return horas * 2000; 
            } else if (vehiculo instanceof Motocicleta) {
                return horas * 1000; 
            } else if (vehiculo instanceof Camion) {
                return horas * 5000; 
            } 
        } 
    }
    
    throw new IllegalArgumentException("Vehículo no encontrado en el parqueadero.");
    }
    public void generarReporteDiario() {
        LocalDate hoy = LocalDate.now();

        System.out.println("\n--- Reporte Diario ---");
        for (Vehiculo vehiculo : Vehiculos) {
            if (vehiculo.getHoraEntrada().toLocalDate().equals(hoy)) { 
                System.out.println("Placa: " + vehiculo.getPlaca());
                System.out.println("Marca: " + vehiculo.getMarca());
                System.out.println("Modelo: " + vehiculo.getModelo());
                System.out.println("Hora de entrada: " + vehiculo.getHoraEntrada());
                

                if (vehiculo instanceof Automovil) {
                    System.out.println("Tipo de combustible: " + ((Automovil) vehiculo).getTipoCombustible());
                    System.out.println("Tipo de vehiculo: Automovil");
                } else if (vehiculo instanceof Motocicleta) {
                    System.out.println("Cilindraje: " + ((Motocicleta) vehiculo).getCilindraje());
                    System.out.println("Tipo de vehiculo: Motocicleta");
                } else if (vehiculo instanceof Camion) {
                    System.out.println("Capacidad de carga: " + ((Camion) vehiculo).getCapacidadCarga());
                    System.out.println("Tipo de vehiculo: Camion");
                }

                System.out.println("----------------------"); 
            }
        }
    }
    
}