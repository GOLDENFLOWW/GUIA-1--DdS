
import java.io.*;
import java.util.*;
import java.time.LocalDateTime;

/**
 * 
 */
public class Camion extends Vehiculo {
        public double capacidadCarga;

    public Camion(String placa, String marca, String modelo, double capacidadCarga, LocalDateTime horaEntrada) {
        super(placa, marca, modelo, horaEntrada);
        this.capacidadCarga = capacidadCarga;
    }

    // Getters y Setters
    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;

    }

}