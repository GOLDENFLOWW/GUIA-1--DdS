
import java.io.*;
import java.util.*;
import java.time.LocalDateTime;
/**
 * 
 */
public class Motocicleta extends Vehiculo {
        public int cilindraje;

    public Motocicleta(String placa, String marca, String modelo, int cilindraje, LocalDateTime horaEntrada) {
        super(placa, marca, modelo, horaEntrada);
        this.cilindraje = cilindraje;
    }
    public int getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;

    }

}