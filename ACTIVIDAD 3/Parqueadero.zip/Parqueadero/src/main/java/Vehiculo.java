
import java.io.*;
import java.util.*;
import java.time.LocalDateTime;

/**
 * 
 */
public class Vehiculo {
        public String placa;
        public String marca;
        public String modelo;
        public LocalDateTime horaEntrada;
    
    /**
     * Default constructor
     */
    public Vehiculo(String placa, String marca, String modelo, LocalDateTime horaEntrada) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.horaEntrada = horaEntrada; 
    }
    public String getPlaca() {
         return placa;
    }
    public String getMarca() {
         return marca;
    }  
    public String getModelo() {
         return modelo;
    }
    public LocalDateTime getHoraEntrada() {
         return horaEntrada;
    }  
    public void setHoraEntrada(LocalDateTime horaEntrada) {
         this.horaEntrada=horaEntrada;
     }       
    public void setPlaca(String placa) {
         this.placa=placa;
     }   
    public void setmodelo(String modelo) {
         this.modelo=modelo;
    }
    public void setMarca(String marca) {
         this.marca=marca;
    }
        // TODO implement here

}