
import java.time.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Parqueadero parqueadero = new Parqueadero();
        Scanner scanner = new Scanner(System.in);

       LocalDateTime horaIngreso = LocalDateTime.now();
       
        int opcion;
        do
 {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Ingresar vehiculo");
            System.out.println("2. Registrar salida");
            System.out.println("3. Consultar estado");
            System.out.println("4. Generar reporte diario");
            System.out.println("5. Salir");
            System.out.print("Ingrese una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

              
            switch (opcion) {
                case 1:
                    System.out.print("Tipo de vehículo (1: Automóvil, 2: Motocicleta, 3: Camión): ");
                    int tipoVehiculo = scanner.nextInt();
                    scanner.nextLine(); // Consumir el salto de línea

                    System.out.print("Placa: ");
                    String placa = scanner.nextLine();
                    System.out.print("Marca:   ");
                    String marca = scanner.nextLine();
                    System.out.print("Modelo: ");
                    String modelo = scanner.nextLine(); 


                    Vehiculo vehiculo;
                    if (tipoVehiculo == 1) {
                        System.out.print("Tipo de Combustible: ");
                        String tipoCombustible = scanner.nextLine();
                        vehiculo = new Automovil(placa, marca, modelo, tipoCombustible, horaIngreso);

                    } else if (tipoVehiculo == 2) {
                        System.out.print("Cilindraje: ");
                        int cilindraje = scanner.nextInt();
                        scanner.nextLine();
                        vehiculo = new Motocicleta(placa, marca, modelo, cilindraje, horaIngreso);

                    } else if (tipoVehiculo == 3) {
                        System.out.print("Capacidad de Carga: ");
                        double capacidadCarga = scanner.nextDouble();
                        scanner.nextLine(); // Consume the newline
                        vehiculo = new Camion(placa, marca, modelo, capacidadCarga, horaIngreso); 

                    } else {
                        System.out.println("Tipo de vehículo inválido.");
                        break; // Salir del case si el tipo es inválido
                    }

                    parqueadero.registrarEntrada(vehiculo);
                    break;

                case 2:
                    System.out.print("Placa del vehículo que sale: ");
                    String placaIngreso = scanner.nextLine();
                    try {
                        double costo = parqueadero.registrarSalida(placaIngreso);
                        System.out.println("Costo total: $" + costo);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 3:
                    List<Vehiculo> vehiculos = parqueadero.consultarEstado();
                    if (vehiculos.isEmpty()) {
                        System.out.println("El parqueadero está vacío.");
                    } else {
                        System.out.println("\nVehículos en el parqueadero:");
                        for (Vehiculo vehiculoregistrados : vehiculos) {
                            System.out.println("- Placa: " + vehiculoregistrados.getPlaca() + 
                                               ", Marca: " + vehiculoregistrados.getMarca() + 
                                               ", Modelo: " + vehiculoregistrados.getModelo()); 
                                               
                        }
                    }
                    break;

                case 4:
                    parqueadero.generarReporteDiario();
                    break;

                case 5:
                    System.out.println("¡Hasta luego!");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 5);

        scanner.close();
    }
}
